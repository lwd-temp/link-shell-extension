#define SYS_FILE _T("symlink.sys")
#define SYS_NAME _T("SymLink")
